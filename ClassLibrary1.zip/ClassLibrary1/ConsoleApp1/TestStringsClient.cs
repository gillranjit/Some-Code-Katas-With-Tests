﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class TestStringsClient
    {
        /*
        create a function that parses a string and returns valid or not

        example:
        () = true
        (( = false
        )( = false
        (() = false
        (hello) = true
        )hello( = false
        */
        //static string testString = "dfsgdsgf(()((hello)stringcontinued";
        //const string INVALID = "INVALID";
        //public static Func<string, string, bool> validAndHasFullParentheses = (baseString, pattern) => !baseString.Contains(INVALID) && baseString.Contains(pattern);
        //public static Func<string, string, bool> validAndHasDoubleStartParentheses = n => !n.Contains(INVALID) && n.Contains("((");
        //public static Func<string, string, bool> validAndHasEndOpposedParentheses = n => !n.Contains(INVALID) && n.Contains(")(");
        //public static Func<string, string, bool> validAndHasStartParenthesis = n => !n.Contains(INVALID) && n.Contains("(");
        //public static Func<string, string, bool> validAndHasEndParenthesis = n => !n.Contains(INVALID) && n.Contains(")");
        //public static Func<string, string, bool> validAndHasHello = n => !n.Contains(INVALID) && n.Contains("hello");
    }
}
