﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            AggregateOperations.PrintAgggregateResults("1111333348888", true);
            Console.WriteLine("-------------------------------------");
            AggregateOperations.PrintAgggregateResults("54373474958398456", true);
            Console.Read();
        }

        
    }
}
