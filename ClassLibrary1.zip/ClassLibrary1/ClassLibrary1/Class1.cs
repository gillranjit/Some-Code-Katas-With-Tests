﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ClassLibrary1
{
    public class SortingClass
    {
        public static void PrintAgggregateResults(string numericString)
        {
            if(Int64.TryParse(numericString, out _))
            {
                var collectionOfIntegers = ReturnNumbersInaAString(numericString);
                var integerFrequencyResults = ReturnFrequencyOfNUmber(collectionOfIntegers);
                foreach(string frequencyResult in integerFrequencyResults)
                {
                    Console.WriteLine(frequencyResult);
                }
                //for(int integer = 0;integer < 10; integer++)
                //{

                //}
                
                
            }
            
        }

        private static IEnumerable<string> ReturnFrequencyOfNUmber(IEnumerable<int> collectionOfIntegers)
        {
            for (int counter = 0; counter < 10; counter++)
            {
                yield return counter.ToString() + ":" +  (collectionOfIntegers as IList<int>).Count(n => n == counter) ;
            }
        }
        private static IEnumerable<int> ReturnNumbersInaAString(string numericString)
        {
            foreach (char numericChar in numericString)
            {
                yield return Int32.Parse(numericChar.ToString());
            }
        }
    }
}
